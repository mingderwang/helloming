# Python3 serverless for scaleway.com
# build
```
yarn
```
# dev
```
sls offline start
```
# deploy
```
sls deploy
```
